﻿using System.Threading.Tasks;

namespace EdgeDiagnose
{
    public interface IChatHub
    {
        Task MessageReceivedFromHub(ChatMessage message);

        Task NewUserConnected(string message);
    }
}
