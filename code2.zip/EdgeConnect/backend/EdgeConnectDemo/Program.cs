﻿using System;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR.Client;

namespace EdgeConnectDemo
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Console.WriteLine("Please type your message!");

            HubConnection connection = new HubConnectionBuilder()
                .WithUrl("https://localhost:5001/signalr")
                .WithAutomaticReconnect()
                .Build();

            await connection.StartAsync();

            // string message = Console.ReadLine();

            //await connection.InvokeAsync("SendMessage", "User Console", message);
            // var nxg = new PluginNXG() { Name = "My first plugin" };

            var msg = new ChatMessage()
            {
                ConnectionId = connection.ConnectionId,
                Text = "Console App",
                DateTime = DateTime.Now
            };

            // Console.Write(nxg);

            await connection.InvokeAsync("BroadcastAsync", msg);

            /*   Console.WriteLine("Message Sent to server and listening message from server!");

               connection.On<string, string>("ReceiveMessage",
               (string user, string message) =>
                   {
                       Console.WriteLine($"Message from Web {user}: {message}");
                   });

               string waitingConsole = Console.ReadLine();*/

             

               connection.On<ChatMessage>("messageReceivedFromHub",
               (ChatMessage user) =>
                   {
                       Console.WriteLine($"Message from Web {user.ConnectionId}: {user.Text}");
                   });

               string waitingConsole = Console.ReadLine();

            


        }
    }
}
