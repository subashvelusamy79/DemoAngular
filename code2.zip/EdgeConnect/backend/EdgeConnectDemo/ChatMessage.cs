﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EdgeConnectDemo
{
    public class ChatMessage
    {
        public string Text { get; set; }
        public string ConnectionId { get; set; }
        public DateTime DateTime { get; set; }
    }
}
