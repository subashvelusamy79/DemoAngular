export interface chatMesage {
  Text: string;
  ConnectionId: string;
  DateTime: Date;
}
