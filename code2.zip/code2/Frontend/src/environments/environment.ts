export const environment = {
  production: false,
  communicationshopUrl:"http://localhost:5000/api/Communications/"
};
