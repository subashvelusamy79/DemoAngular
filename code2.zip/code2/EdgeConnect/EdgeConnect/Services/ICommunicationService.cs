﻿using EdgeConnect.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EdgeConnect.Services
{
    public interface ICommunicationService
    {
        List<Communication> GetProduct(string connectionID);
        Task UpdateProduct(Communication communication);
        Communication GetByIdProduct(int productId);
    }
}
