﻿using EdgeConnect.Entity;
using System.Threading.Tasks;

namespace EdgeConnect.Hubs.Abstract
{
    public interface IHubCommunicationDispatcher
    {
        Task ChangeProduct(Communication communication);
    }
}
