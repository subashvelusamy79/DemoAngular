# NetCore_Angular_RealTimeShop
Real-Time Product Editing in an Online Shop with .Net Core, SignalR and Angular 12

![Animation2](https://user-images.githubusercontent.com/50150182/129485386-78213f31-f666-4052-95ef-392f2241025c.gif)
